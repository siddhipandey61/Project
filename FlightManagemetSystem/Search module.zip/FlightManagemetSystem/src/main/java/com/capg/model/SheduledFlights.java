package com.capg.model;

public class SheduledFlights {
	private int scheduledId;
	private int flightId;
	public int getScheduledId() {
		return scheduledId;
	}
	public void setScheduledId(int scheduledId) {
		this.scheduledId = scheduledId;
	}
	public int getFlightId() {
		return flightId;
	}
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
	
	
}
