package com.capg.fms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightManagemetSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightManagemetSystemApplication.class, args);
	}

}
